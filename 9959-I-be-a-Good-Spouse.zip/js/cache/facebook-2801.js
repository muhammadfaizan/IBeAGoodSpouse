﻿/// <reference group="Dedicated Worker" />

onmessage = function (event) {

}
